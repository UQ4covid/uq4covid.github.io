---  
title: MetaWards
author: "Danny Williamson and TJ McKinley"
date: "22 June 2020"
output: 
  html_document:
    code_folding: show
layout: default
---



# Introduction {.tabset .tabset-fade}

This vignette contains all the details about the current UQ4Covid MetaWards implementation. It consists of various sections that can be accessed through the tabs below:

* **Quick Start Guide**: contains instructions about how to install and run this version of MetaWards.
* **Model Description**: A short guide to the model inputs and outputs.
* MetaWards setup: A more detailed guide to the ins-and-outs of the model structure, and details of the implementation.

**All necessary files can be downloaded from [here](../metawards.zip).**



## Quick Start Guide {#quickstart}

When performing UQ, it can hardly be overstated how useful it can be to run the model you are analysing for yourself. Obviously, if you can, as with Metawards, this comes with its own problems and dangers, and you might run the model in such a way as not to get anything useful out. Thanks to the work of our team (TJ McKinley and Chris Fenton in particular), and with help from Metawards developer Christopher Woods, we have a model structure [described here](https://uq4covid.github.io/vignettes/data/MetaWards/vignette/MetaWards) and a stable version of the code for running it for UQ and extracting the data for yourselves! 

So why am I writing a "for dummies" guide to using it and not Chris/TJ? Well, because I qualify as a member of the target audience! Today, I went through TJ's instructions, failed in several places and figured out everything I needed to do to run it, so I figured I would pass that knowledge on.

### Instructions for Linux/Mac

As Mac uses Unix and I am on a Mac, the instructions are identical. There will need to be tweaks to the below for Windows users, but what is here should be enough to get you started.

### Install Metawards

The easiest thing to do is to open a terminal and type

```bash
pip3 install metawards
```

I used `pip3`, you may have Python 3 as default and can use `pip`. The absolute best thing to do is go [here](https://metawards.org/install.html) and follow the instructions. They are really clear. For this part it doesn't matter what directory you are in.

Now, you need to head to a directory where you want the Metawards data to live. If not familar with terminal navigation, I used

```bash
cd Dropbox/BayesExeter
```

and you can check if you are happy with what's in the directory with

```bash
ls
```

Next install the metawards data files with 

```bash
git clone https://github.com/metawards/MetaWardsData
```

### Get the uq4covid version

Now, we get our version of the model, which consists of a number of files needed to do the running, designing and extracting.

**These can be downloaded as a `.zip` file [here](../metawards.zip).**

Alternatively, these are also on the `uq4covid.io` repository [here](https://github.com/UQ4covid/uq4covid.github.io), which you should clone onto your machine or pull if you have it already.

Once you have it, go to directory `vignettes/data/MetaWards` and there is everything you need. **To ensure we keep the repo version clean, it's best to copy this folder out to somewhere else.** This guide is going to use RStudio to do most things, so head to this folder in Rstudio and set it as your working directory.

### Generating a new design

The file `convertDesign.R` creates new designs to your specification. To run a custom design, you need to open it and change a few things. I'll highlight the blocks you need to look at now.

First the parameter ranges look like this

```r
parRanges <- data.frame(
    parameter = c("r_zero", "incubation_time", "infectious_time", "hospital_time",
                  "critical_time", "lock_1_restrict", "lock_2_release",
                  "pEA", "pIH", "pIRprime", "pHC", "pHRprime", "pCR", 
                  "GP_A", "GP_H", "GP_C"),
    lower = c(2.5, 4, 2, 4, 4, rep(0, 11)),
    upper = c(4, 6, 4, 12, 12, rep(1, 11)),
    stringsAsFactors = FALSE
)
```

You can alter `lower` and `upper` for any of the parameters (or even fix some if you like) here. See the model description linked at the top to see what they all do.

Next, generate your own design. The default is a test 5 member LHC and is in the code like this

```r
design <- randomLHS(5, nrow(parRanges))
colnames(design) <- parRanges$parameter
design <- as_tibble(design)
```

Obviously, change the design to something of your own choosing (remembering at all times how bad random Latin Hypercubes can be), replacing the first of these 3 lines with your own.

The next 2 lines are super important

```r
design$output <- ensembleIDGen(ensembleID = "Ens0", nrow(design))
design$repeats <- 2
```

The second gives the number of repeats per run so is fairly obvious. Our early experiments showed that at least 20 might be needed for some good techniques to work. The output argument is very important. This is a unique identifier for the ensemble. `"Ens0"` is the first test ensemble we've run. `"Ens1"` will be the next. Soon there will be `"Ens9"`, `"Ensa"`, `"Ensb"` and so on. We use "Ens" as Metawards does funny things if you use numbers or some single letters. Ideally, you would let us know you are generating a big ensemble with the next ID for putting on the git page. This identifier will ultimately be responsible for identifying your ensemble from others, and for matching inputs to outputs during extraction. Change it now.

One you have made those changes, run the whole script and you are ready to run metawards!

### Running Metawards

There are 2 simple steps to this. First, you need to edit the file `runscript.sh`. Simply open it with xcode, and alter the line

```bash
export METAWARDSDATA=$HOME/Dropbox/BayesExeter/MetaWardsData
```
so that the direcroty is the place you cloned the Metawards data above. Now it's run time! The default is to run for 100 days, but you will probably want longer to look at interesting things. The final part of the long line calling Metawards handles this

```bash
--nsteps 100
```

and you can alter it in obvious ways.

Open up a terminal and navigate via `cd` to the folder where your `runscript.sh` is. Once there type

```bash
./runscript.sh
```

and let the fun begin. Even this small test ensemble took about 10 mins on my machine, and it runs on all the cores, so don't expect to be able to do a tonne whilst it's running. TJ had a bigger job run all night.

### Extracting data

Eventually the fans will cool down and the simulations will be complete. Now you will want to get at some of the outputs. The `extractOutput.R` file lets you do this. Open this in RStudio.

If you have all the required libraries, you can just run the whole thing and, by default, you will get the total number of infections in hospitals per ward. There is a lot you can do to customise, and details can be found in the **Model Description** tab above. To get you started, here are some things you can change. 

The chunk

```r
hospital <- tbl(con, "hospital_totals")
        hosp_db <- filter(hospital, day <= 100) %>%
            select(ward, stage_2) %>%
            group_by(ward) %>%
            summarise(cH = sum(stage_2))
        ## collect outcome of query
        hosp <- collect(hosp_db)
```

is taking the database `con` created from the raw outputs, is selecting those from the `hospital` demographic, and summing the numbers at stage 2. Some reference to our model setup is required to see what to do, so maybe head there to see what the stages and demographics refer to in the diagram. We have 4 demographics:
`genpop` , `hospital` , `critical`, and `asymp` (so you can substitute for any of these). There are 6 stages indexed 0-5 (so above we have stage 2). The diagram in TJ's instruction shows where they are, but there are 2 things to note. Stages 0 and 2 count the new incidents of entry into that demographic *that day*. Stages 1 and 3 count the total incidents in that demographic that day *including the new ones from 0 and 1 respectively*. It's a postprocessing trick, meaning that we get the most informative data each time. Stage 4 is recovered and stage 5 is death.

Having extracted data like this in tibble form, it is ready to be processed for building whatever emulators you like.

### Sundries

All of the files for running Metawards are in the different folders in our repo (that you will have cloned onto your machine), so you are free to change things for your own investigations. In the future, when we decide on different experiments we want to do, we will alter these files, but still be able to retain the same designing, running and processing experience.

Happy UQing!


## Model Description {#modelS}

The basic model structure is:

* $E$: infected but not infectious;
* $A$: asymptomatic and infectious;
* $I$: symptomatic and infectious;
* $H$: hospitalised and infectious;
* $C$: in critical care (ICU) and infectious;
* $R$: recovered and immune;
* $D$: died.

![plot of chunk unnamed-chunk-15](figure/unnamed-chunk-15-1.png)

### MetaWards setup

The model structure above allows for different progression pathways. MetaWards deals with this by assigning individuals to different "demographics", where each demographic can be used to represent different progression pathways. There are currently seven pathways, which will be described below, which can be summarised as:

* `SEAR`: asymptomatic infections, always recover.
* `SEIR`: symptomatic infections, leading to recovery.
* `SEID`: symptomatic infections, leading to death.
* `SEIHR`: symptomatic infections, leading to hospital and then recovery.
* `SEIHD`: symptomatic infections, leading to hospital and then death.
* `SEIHCR`: symptomatic infections, leading to hospital, then critical care (ICU) and then recovery.
* `SEIHCD`: symptomatic infections, leading to hospital, then critical care (ICU) and then death.

Individuals in the `genpop` demographic move through the $SEIR$ and $SEID$ pathways; the `asymp` demographic moves through the `SEAR` pathway; some individuals in the `genpop` demographic can be moved to the `hospital` demographic, and thus follow the `SEIHR` and `SEIHD` pathways; and finally, some individuals in the `hospital` demographic can be moved to the `critical` demographic, and thus follow the `SEIHCR` and `SEIHCD` pathways.

### Parameters {#parametersS}

Movements through the different states are governed by key parameters:

* $p_{SE}$ driven by $\beta$ parameters, defined by $R_0$ and length of infectious period (see [here](#codeS));
* $p_{EA} = p_{EA}\left(1 - e^{-\gamma_{E}}\right)$ where $\gamma_E = \frac{1}{T_E}$ with $T_E$ the mean incubation period;
* $p_{EI} = \left(1 - p_{EA}\right)\left(1 - e^{-\gamma_{E}}\right)$;
* $p_{AR} = 1 - e^{-\gamma_I}$ where $\gamma_I = \frac{1}{T_I}$ with $T_I$ the mean infectious period;
* $p_{IH} = p_{IH}\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{IR} = p_{IR}\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{ID} = \left(1 - p_{IH} - p_{IR}\right)\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{HC} = p_{HC}\left(1 - e^{-\gamma_{H}}\right)$ where $\gamma_{H} = \frac{1}{T_H}$ with $T_H$ the mean length of a hospital stay;
* $p_{HR} = p_{HR}\left(1 - e^{-\gamma_{H}}\right)$;
* $p_{HD} = \left(1 - p_{HC} - p_{HR}\right)\left(1 - e^{-\gamma_{H}}\right)$;
* $p_{CR} = p_{CR}\left(1 - e^{-\gamma_{C}}\right)$ where $\gamma_C = \frac{1}{T_C}$ with $T_C$ is the mean length of time spent in ICU;
* $p_{CD} = \left(1 - p_{CR}\right)\left(1 - e^{-\gamma_{C}}\right)$.

Lockdown can be controlled either by constraining movements over a certain distance, or by scaling the $\beta$ parameters. We do the latter at the moment.

### Interaction matrices

The **interaction matrix** scales the force-of-infection (FOI) that different demographics have on other demographics. We have three free parameters here: $\beta^S_{A \to GP}$, $\beta^S_{H \to GP}$ and $\beta^S_{C \to GP}$ which scale the impact of aymptomatics, hospital cases and critical care cases on the FOI to the general population. 

### Input parameters {#inputS}

To run designs, we need to generate a `disease.csv` file containing different parameters to use for different runs. For consistency, we will define three spaces:

* *input* space: this relates to the parameters ranges (defined below);
* *design* space: this will usually be in $(0, 1)$ or $(-1, 1)$ space;
* *disease* space: this relates to parameters that are fed into MetaWards.

The *input* and *design* spaces are fairly trivial to convert between, but some more work has to be done to convert between the *input* space and the *disease* space. To ensure orthogonality, we reparameterise a couple of the parameters such that:
\begin{align}
    p_{IR} &= \left(1 - p_{IH}\right) p^\prime_{IR}\\
    p_{HR} &= \left(1 - p_{HC}\right) p^\prime_{HR}
\end{align}
and thus we have parameter ranges:
\begin{align}
    \mbox{$R_0$}&: (2.5, 4)\\
    \mbox{mean incubation period ($T_E$)}&: (4, 6)\\
    \mbox{mean infectious period ($T_I$)}&: (2, 4)\\
    \mbox{mean hospital stay ($T_H$)}&: (4, 12)\\
    \mbox{mean time in critical care ($T_C$)}&: (4, 12)\\
    \mbox{lockdown 1 restrict}&: (0, 1)\\
    \mbox{lockdown 2 release}&: (0, 1)\\
    p_{EA}&: (0, 1)\\
    p_{IH}&: (0, 1)\\
    p^\prime_{IR}&: (0, 1)\\
    p_{HC}&: (0, 1)\\
    p^\prime_{HR}&: (0, 1)\\
    p_{CR}&: (0, 1)\\
    \beta^S_{A \to GP}&: (0, 1)\\
    \beta^S_{H \to GP}&: (0, 1)\\
    \beta^S_{C \to GP}&: (0, 1).
\end{align}

### Outputs {#outputS}

The outputs from MetaWards are stored in an SQL database, which can be queried through any SQLite client. Each model run produces a file called `stages.db.bz2`, which is a compressed database containing the outputs. To access this you will first have to unzip it. I do this on the command line e.g.

```
bzip2 -dk stages.db.bz2
```

You will notice that the unzipped `stages.db` file is **much** larger than the compressed version, so we need to be careful to remove `stages.db` at the end if we have limited hard drive space. The database contains four tables:

* `genpop_totals`
* `hospital_totals`
* `asymp_totals`
* `critical_totals`

You will notice these are named after the different **demographics**. Each table contains entries for:

* `ward`, `day`, `stage_0`, `stage_1`, `stage_2`, `stage_3`, `stage_4`, `stage_5`

For the `genpop` demographic, these correspond to:

* `stage_0`: **new** infections on each day (i.e. new moves into $E$)
* `stage_1`: current infections on each day (i.e. number of individuals in $E$)
* `stage_2`: **new** infectious individuals on each day (i.e. new moves into $I$)
* `stage_3`: current infectious individuals on each day (i.e. number of individuals in $I$)
* `stage_4`: current removals on each day (i.e. number of individuals in $R$)
* `stage_5`: current deaths on each day (i.e. number of individuals in $D$)

The other demographics (`asymp`, `hospital` and `critical`) have the same structure, but with `stage_0` and `stage_1` **always 0** (since new infections are always in `genpop`), and `stage_2` and `stage_3` correspond to the new and current numbers in either the $A$, $H$ or $C$ classes according to the demographic (refer to the model structure [here](#modelS)).

If you're happy with SQL, you can query these directly with e.g. SQLite. If you are an R user, then the `dplyr` package (or more specifically the `dbplyr` package) provides some useful R tools for querying SQL databases using `tidyverse`-type notation. More details can be found [here](https://cran.r-project.org/web/packages/dbplyr/vignettes/dbplyr.html).

As a quick example, imagine that we want to extract the **cumulative hospital cases** on say day 100. Here we will need to extract the **new hospital cases** from day 1--100, and then sum them up for each ward. Therefore we need to extract `day`, `ward` and `stage_2` from the `hospital_totals` table, and then sum them up. For speed, `dplyr` converts the R code to SQL, and only pulls the resulting table to R if you run the function `collect()` (see below).


```r
## load library
## (you might also need to install the 'RSQLite' 
## and `dbplyr` packages which 'dplyr' calls)
library(dplyr)

## establish connection to database
con <- DBI::dbConnect(RSQLite::SQLite(), "stages.db")

## connect to the 'hospital_totals' table
hospital <- tbl(con, "hospital_totals")

## stage_2 contains the new cases, so sum these
## over each ward for days 1--100 
## (NOTE: `hosp_db` contains the query not the outcome,
## so 'show_query(hosp_db)' can view this if you like)
hosp_db <- filter(hospital, day <= 100) %>%
    select(ward, stage_2) %>%
    group_by(ward) %>%
    summarise(cH = sum(stage_2))

## run query and pull to R
hosp <- collect(hosp_db)

## disconnect from database
DBI::dbDisconnect(con)
```

Now you can play with `hosp` as much as you like. Note that after you've pulled the correct outputs down, you might want to delete the `stage.db` (**NOT** the `stages.db.bz2`) file. I did this on the Unix command line using:

```
rm stage.db
```

> **Be careful**: remember that `rm` removes completely, so not to the recycle bin. However, as long as you don't remove `stages.db.bz2` then you can always recover.

You can very easily wrap these ideas into an R function that can scroll through the design IDs, extract relevant outputs and bind to the inputs. An example that you are free to edit at will can be found in the `extractOutputs.R` file in the repo.



## MetaWards Model Structure {#model}

> **In order to get the model structure and outputs described previously, we have to play a few tricks in MetaWards. The detail below corresponds to how we have implemented the current model, and requires additional stages to ensure we get the correct transitions and outputs.**

Here most classes are split into two components, e.g. $E_1$ and $E_2$. This is so that MetaWards can calculate new movements into each class easily, but are otherwise epidemiologically identical. Here:

* $E$: infected but not infectious;
* $A$: asymptomatic and infectious;
* $I$: symptomatic and infectious;
* $H$: hospitalised and infectious;
* $C$: in critical care (ICU) and infectious;
* $R$: recovered and immune;
* $D$: died.

![plot of chunk unnamed-chunk-17](figure/unnamed-chunk-17-1.png)

### MetaWards setup

The model structure above allows for different progression pathways. MetaWards deals with this by assigning individuals to different "demographics", where each demographic can be used to represent different progression pathways. There are also `mover` functions that can be used to move individuals between demographics, and `mixer` functions that scale the force-of-infection (FOI) terms between the different demographics (explained later). There are currently seven pathways, which will be described below, but can be summarised as:

* `SEAR`: asymptomatic infections, always recover.
* `SEIR`: symptomatic infections, leading to recovery.
* `SEID`: symptomatic infections, leading to death.
* `SEIHR`: symptomatic infections, leading to hospital and then recovery.
* `SEIHD`: symptomatic infections, leading to hospital and then death.
* `SEIHCR`: symptomatic infections, leading to hospital, then critical care (ICU) and then recovery.
* `SEIHCD`: symptomatic infections, leading to hospital, then critical care (ICU) and then death.

In practice, we can summarise these through four demographics, and then `move` functions that conditionally move individuals through the seven pathways. First, we set up the `demographics.json` file, which should look something like:



```js
{
  "demographics" : ["genpop", "asymp", "hospital", "critical"],
  "work_ratios"  : [ 1.0, 0.0, 0.0, 0.0 ],
  "play_ratios"  : [ 1.0, 0.0, 0.0, 0.0 ],
  "diseases"     : [ "ncov", "ncov", "ncov", "ncov" ]
}
```

Individuals in the `genpop` demographic move through the $SEIR$ and $SEID$ pathways; the `asymp` demographic moves through the `SEAR` pathway; some individuals in the `genpop` demographic can be moved to the `hospital` demographic, and thus follow the `SEIHR` and `SEIHD` pathways; and finally, some individuals in the `hospital` demographic can be moved to the `critical` demographic, and thus follow the `SEIHCR` and `SEIHCD` pathways.

We need to specify initial proportions of individuals in each pathway such that $\sum_{i \in \mathcal{P}} p_i = 1$, where $\mathcal{P} = \{GP, A, H, C\}$.

> Here we assume the same ratios in the `work` and `play` populations, but in practice these could be changed.

### Parameters {#parameters}

Once the demographics have been setup, we can then control progress through the different states as:

* $p_{SE_1}$ driven by $\beta$ parameters, defined by $R_0$ and length of infectious period (see [here](#code));
* $p_{E_1E_2} = 1$;
* $p_{E_2A_1} = p_{EA}\left(1 - e^{-\gamma_{E}}\right)$ where $\gamma_E = \frac{1}{T_E}$ with $T_E$ the mean incubation period;
* $p_{E_2I_1} = \left(1 - p_{EA}\right)\left(1 - e^{-\gamma_{E}}\right)$;
* $p_{A_1A_2} = 1$;
* $p_{A_2R} = 1 - e^{-\gamma_I}$ where $\gamma_I = \frac{1}{T_I}$ with $T_I$ the mean infectious period;
* $p_{I_1I_2} = 1$;
* $p_{I_2H_1} = p_{IH}\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{I_2R} = p_{IR}\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{I_2D} = \left(1 - p_{IH} - p_{IR}\right)\left(1 - e^{-\gamma_{I}}\right)$;
* $p_{H_1H_2} = 1$;
* $p_{H_2C_1} = p_{HC}\left(1 - e^{-\gamma_{H}}\right)$ where $\gamma_{H} = \frac{1}{T_H}$ with $T_H$ the mean length of a hospital stay;
* $p_{H_2R} = p_{HR}\left(1 - e^{-\gamma_{H}}\right)$;
* $p_{H_2D} = \left(1 - p_{HC} - p_{HR}\right)\left(1 - e^{-\gamma_{H}}\right)$;
* $p_{C_1C_2} = 1$;
* $p_{C_2R} = p_{CR}\left(1 - e^{-\gamma_{C}}\right)$ where $\gamma_C = \frac{1}{T_C}$ with $T_C$ is the mean length of time spent in ICU;
* $p_{C_2D} = \left(1 - p_{CR}\right)\left(1 - e^{-\gamma_{C}}\right)$.

Lockdown can be controlled either by constraining movements over a certain distance, or by scaling the $\beta$ parameters. We do the latter at the moment. The moves of the type $p_{X_1X_2} = 1$ are tricks to enable us to get the correct counts (see [below](#movements) for more details).

### Disease `.json` file {#diseasefile}

All pathways have an $SEI(R/D)$ structure, so we can set up an `ncov.json` file for the overall disease:


```js
{ 
  "name"             : "SARS-Cov-2",
  "version"          : "June 11th 2020",
  "author(s)"        : "UQ4COVID Team",
  "contact(s)"       : "e-mail...",
  "reference(s)"     : "references...",  
  "beta"             : [0.0, 0.0, 1.0, 1.0, 0.0, 0.0],
  "progress"         : [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  "too_ill_to_move"  : [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  "contrib_foi"      : [1.0, 1.0, 1.0, 1.0, 0.0, 0.0]
}
```

We will discuss these choices in more detail in the subsequent sections, in particular the role of the `beta` parameters in the next section. Note that the `progress` parameters are all set to zero here, since all movements will be controlled via the custom `mover` function.

### Controlling movements {#movements}

MetaWards has a specific structure in terms of how it progresses movements between the stages. To get the correct splits between the pathways specified [above](#model) we do all non-infection movements through a custom `mover` function specified [below](#mover). Note that the $X_1$-type states (e.g. $E_1$, $I_1$, $H_1$ and $C_1$) are dummy states that allow us to monitor *new moves into each class at each day*. Note that in the `ncov.json` file specified [above](#diseasefile), we set all `progress` parameters to be 0. Thus, all transition probabilities other than new infections are driven by user-defined parameters that are passed to the `mover` function.

All this effort is so that we can monitor the counts and ensure the correct transitions, and depends on the order in which the events happen. For example, imagine that on day $t$ we get an infection at the end of the day, so a move from $S \to E_1$. Then the **recorded counts** for $E_1$ contain the new infections. Then, at the beginning of day $t + 1$, these individuals will be automatically moved from $E_1 \to E_2$ by the mover function, which subsequently operates using the probabilities [above](#parameters) to ensure the correct proportion of individuals progress into the $I_1$ or $A_1$ classes. The `mover` function applies movements in order, and so it is important to get the order correct. In particular we need to reverse the order of the stage movements (e.g. do movements out of the $C$ demographic *before* movements out of the $H$ demographic). This is to ensure that individuals move from $H_2 \to C_1$ say, can't then immediately move out of $C_1$. However, *within* each stage, we need to do $X_1 \to X_2$ moves first so that these individuals can progress out of $X_2$ subsequently (since the $X_1$ stages are simply dummy stages used for counting).

> **Note**: remember that $X_1$ and $X_2$ are tricks here. We want $X_1$ to record the number of **new movements into** class $X$, and $X_2$ to record the **number of individuals in** class $X$. At the moment, moves into $X_1$ on day $t$ say are not currently included in $X_2$. Epidemiologically these are treated OK, since the [`mover`](#mover) below accounts for the transitions correctly. However, we want the outputs for the $X_2$ type classes to be the **number of individuals** in that class on each day. As such, we use a custom [`extractor`](#extractor) function that adds $X_1$ to $X_2$ at the end, so that $X_1$ corresponds to **new movements into** the $X$ class, and $X_2$ is the **number** of individuals in the $X$ class.

#### Moving functions {#mover}

The implement the above ideas, create a file `move_pathways.py` containing the code below (hidden for brevity, but can be toggled on).


```python
from metawards.movers import go_stage

def move_pathways(network, **kwargs):

    # extract user defined parameters
    params = network.params

    ## moves out of E class
    pE = params.user_params["pE"]
    pEA = params.user_params["pEA"]
    
    ## moves out of A class
    pA = params.user_params["pA"]
    
    ## moves out of I class
    pI = params.user_params["pI"]
    pIH = params.user_params["pIH"]
    pIR = params.user_params["pIR"]
    
    ## moves out of H class
    pH = params.user_params["pH"]
    pHC = params.user_params["pHC"]
    pHR = params.user_params["pHR"]
    
    ## moves out of C class
    pC = params.user_params["pC"]
    pCR = params.user_params["pCR"]
        
    func = []
    
    ## movers in reverse order through the stages to ensure correct mapping
    
    #######################################################
    #########              C1 MOVES               #########
    #######################################################
    
    ## move C1 critical to C2 critical
    func.append(lambda **kwargs: go_stage(go_from="critical",
                                      go_to="critical",
                                      from_stage=2,
                                      to_stage=3,
                                      fraction=1.0,
                                      **kwargs))
    
    #######################################################
    #########              C2 MOVES               #########
    #######################################################
                                      
    ## move C2 critical to R critical
    tpCR = pC * pCR
    func.append(lambda **kwargs: go_stage(go_from="critical",
                                      go_to="critical",
                                      from_stage=3,
                                      to_stage=4,
                                      fraction=tpCR,
                                      **kwargs))
                                      
    ## move C2 critical to D critical
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpCD = pC * (1.0 - pCR) / (1.0 - tpCR)
    tpCD = 1.0 if tpCD > 1.0 else tpCD
    tpCD = 0.0 if tpCD < 0.0 else tpCD
    func.append(lambda **kwargs: go_stage(go_from="critical",
                                      go_to="critical",
                                      from_stage=3,
                                      to_stage=5,
                                      fraction=tpCD,
                                      **kwargs))
                                      
    #######################################################
    #########              H1 MOVES               #########
    #######################################################
    
    ## move H1 hospital to H2 hospital
    func.append(lambda **kwargs: go_stage(go_from="hospital",
                                      go_to="hospital",
                                      from_stage=2,
                                      to_stage=3,
                                      fraction=1.0,
                                      **kwargs))
                                      
    #######################################################
    #########              H2 MOVES               #########
    #######################################################
    
    ## move H2 hospital to C1 critical
    tpHC = pH * pHC
    func.append(lambda **kwargs: go_stage(go_from="hospital",
                                      go_to="critical",
                                      from_stage=3,
                                      to_stage=2,
                                      fraction=tpHC,
                                      **kwargs))
                                      
    ## move H2 hospital to R hospital
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpHR = pH * pHR / (1.0 - tpHC)
    tpHR = 1.0 if tpHR > 1.0 else tpHR
    tpHR = 0.0 if tpHR < 0.0 else tpHR
    func.append(lambda **kwargs: go_stage(go_from="hospital",
                                      go_to="hospital",
                                      from_stage=3,
                                      to_stage=4,
                                      fraction=tpHR,
                                      **kwargs))
                                      
    ## move H2 hospital to D hospital
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpHD = pH * (1.0 - pHC - pHR) / (1.0 - pH * (pHC + pHR))
    tpHD = 1.0 if tpHD > 1.0 else tpHD
    tpHD = 0.0 if tpHD < 0.0 else tpHD
    func.append(lambda **kwargs: go_stage(go_from="hospital",
                                      go_to="hospital",
                                      from_stage=3,
                                      to_stage=5,
                                      fraction=tpHD,
                                      **kwargs))
                                      
    #######################################################
    #########              I1 MOVES               #########
    #######################################################
    
    ## move I1 genpop to I2 genpop
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="genpop",
                                      from_stage=2,
                                      to_stage=3,
                                      fraction=1.0,
                                      **kwargs))
    
    #######################################################
    #########              I2 MOVES               #########
    #######################################################

    ## move I2 genpop to H1 hospital
    tpIH = pI * pIH
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="hospital",
                                      from_stage=3,
                                      to_stage=2,
                                      fraction=tpIH,
                                      **kwargs))

    ## move I2 genpop to R genpop
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpIR = pI * pIR / (1.0 - tpIH)
    tpIR = 1.0 if tpIR > 1.0 else tpIR
    tpIR = 0.0 if tpIR < 0.0 else tpIR
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="genpop",
                                      from_stage=3,
                                      to_stage=4,
                                      fraction=tpIR,
                                      **kwargs))

    ## move I2 genpop to D genpop
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpID = pI * (1 - pIH - pIR) / (1.0 - pI * (pIH + pIR))
    tpID = 1.0 if tpID > 1.0 else tpID
    tpID = 0.0 if tpID < 0.0 else tpID
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="genpop",
                                      from_stage=3,
                                      to_stage=5,
                                      fraction=tpID,
                                      **kwargs))
                                      
    #######################################################
    #########              A1 MOVES               #########
    #######################################################
    
    ## move A1 asymp to A2 asymp
    func.append(lambda **kwargs: go_stage(go_from="asymp",
                                      go_to="asymp",
                                      from_stage=2,
                                      to_stage=3,
                                      fraction=1.0,
                                      **kwargs))
    
    #######################################################
    #########              A2 MOVES                #########
    #######################################################

    ## move A2 asymp to R asymp
    tpAR = pA
    func.append(lambda **kwargs: go_stage(go_from="asymp",
                                      go_to="asymp",
                                      from_stage=3,
                                      to_stage=4,
                                      fraction=tpAR,
                                      **kwargs))
                                      
    #######################################################
    #########              E1 MOVES               #########
    #######################################################
                                      
    ## move E1 genpop to E2 genpop
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="genpop",
                                      from_stage=0,
                                      to_stage=1,
                                      fraction=1.0,
                                      **kwargs))
    
    #######################################################
    #########              E2 MOVES               #########
    #######################################################

    ## move E2 genpop to A1 asymp
    tpEA = pE * pEA
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="asymp",
                                      from_stage=1,
                                      to_stage=2,
                                      fraction=tpEA,
                                      **kwargs))

    ## move E2 genpop to I1 genpop
    ## (denominator adjustment is due to operating on remainder
    ## as described in the vignette, also includes correction
    ## in case of rounding error)
    tpEI = pE * (1.0 - pEA) / (1.0 - tpEA)
    tpEI = 1.0 if tpEI > 1.0 else tpEI
    tpEI = 0.0 if tpEI < 0.0 else tpEI
    func.append(lambda **kwargs: go_stage(go_from="genpop",
                                      go_to="genpop",
                                      from_stage=1,
                                      to_stage=2,
                                      fraction=tpEI,
                                      **kwargs))

    return func
```

> **Additional note**: The functions in the `mover` file operate in turn. Therefore the movement probabilities [above](#parameters) must be altered between each function, in order to get the correct proportions moved. For example, consider that we have $n$ individuals in the $I_2$ class and we want to move a proportion $p_Ip_{IH}$ from $I_2 \to H_1$, a proportion $p_Ip_{IR}$ from $I_2 \to R_I$, and a proportion $p_I\left(1 - p_{IH} - p_{IR}\right)$ from $I_2 \to D_I$, where $p_I = 1 - e^{-\gamma_I}$.
> 
> In this case the first `mover` function takes a random binomial sample from the $n$ individuals with probability $p_Ip_{IH}$ as requested, resulting in $n_{IH}$ moves. However, the second `mover` function now operates on the $n - n_{IH}$ individuals, so we need to adjust the sampling probabilities to adjust for this. Hence the second `mover` function needs to sample from the $n - n_{IH}$ individuals with probability $\frac{p_Ip_{IR}}{1 - p_Ip_{IH}}$ in order to generate the correct proportions of moves that we would expect, resulting in $n_{IR}$ moves. Similarly, the third `mover` function now operates on the $n - n_{IH} - n_{IR}$ remaining individuals, and thus we would need to adjust the sampling probability to $\frac{p_I\left(1 - p_{IH} - p_{IR}\right)}{1 - p_I\left(p_{IH} + p_{IR}\right)}$. The remaining individuals remain in $I_2$.

### Interaction matrices

The **interaction matrix** scales the FOI that different demographics have on other demographics. We need to store this in a file called `mix_pathways.py`. Since most of the classes are already infected, it's only the first row that has to contain non-zero entries. Here the `GP_A`, `GP_H` and `GP_C` parameters scale the impact of aymptomatics, hospital cases and critical care cases on the force-of-infection to the general population. All demographics other than `genpop` are already infected, so have no further force-of-infection acting on them, and thus the other parameters can be set to zero. These parameters are all $> 0$.


```python
from metawards.mixers import merge_using_matrix

def mix_pathways(network, **kwargs):
    params = network.params

    # how much FOI to GP population is affected by others
    GP_GP = 1.0 
    GP_A = params.user_params["GP_A"]
    GP_H = params.user_params["GP_H"]
    GP_C = params.user_params["GP_C"]

    matrix = [ [GP_GP, GP_A, GP_H, GP_C],
               [0.0, 0.0, 0.0, 0.0],
               [0.0, 0.0, 0.0, 0.0],
               [0.0, 0.0, 0.0, 0.0] ]

    network.demographics.interaction_matrix = matrix

    return [merge_using_matrix]
```

### Lockdown

Chris Fenton wrote a neat custom `iterator` function, that models lockdown by scaling the FOI terms for different time period,s that represent different stages of interventions. The custom iterator is:


```python
#
# Lock-down iterator that simulates various control measures for Covid-19
#
from datetime import datetime
from metawards.utils import Console

# Determine the lock-down status based on the population and current network
# TODO: Now MetaWards accepts dates, so we might be able to simplify this
def get_lock_down_vars(network, population):

    date = population.date
    params = network.params.user_params

    y1 = int(params["lockdown_date_1_year"])
    m1 = int(params["lockdown_date_1_month"])
    d1 = int(params["lockdown_date_1_day"])

    y2 = int(params["lockdown_date_2_year"])
    m2 = int(params["lockdown_date_2_month"])
    d2 = int(params["lockdown_date_2_day"])

    # Lock down dates
    lock_1 = datetime(y1, m1, d1).date()
    lock_2 = datetime(y2, m2, d2).date()
    
    state = 0
    rate = 1.0
    if date >= lock_1:
        state += 1
        rate = params["lock_1_restrict"]
    if date >= lock_2:
        state += 1
        rate = (1.0 - ((1.0 - params["lock_1_restrict"]) * params["lock_2_release"]))

    can_work = params["can_work"][state]
    return state, rate, can_work


#
# Advance in a lock-down state
#
def advance_lock_down(network, population, **kwargs):

    from metawards.iterators import advance_infprob
    from metawards.iterators import advance_play
    from metawards.iterators import advance_fixed

    state, rate, can_work = get_lock_down_vars(network=network, population=population)

    advance_infprob(scale_rate=rate, network=network, population=population, **kwargs)
    advance_play(network=network, population=population, **kwargs)
    if can_work:
        advance_fixed(network=network, population=population, **kwargs)


#
# Iterate as normal, unless it is past a lock-down date
#
def iterate_custom(network, population, **kwargs):
    
    from metawards.iterators import iterate_working_week

    state, rate, can_work = get_lock_down_vars(network=network, population=population)
    Console.print(f"state {state}: scale_rate = {rate}, can_work = {can_work}")    
    
    if state > 0:
        return [advance_lock_down]
    else:    
        return iterate_working_week(network=network, population=population, **kwargs)
```

This requires an additional input file containing the dates of the different stages (which are fixed parameters here). This is stored in the `lockdown_states.txt` file:


```python
# Normal status
.can_work[0]  = True

# Lockdown 1
.can_work[1]  = False

# Lockdown 2
.can_work[2]  = True

# Lockdown dates
.lockdown_date_1_year = 2020
.lockdown_date_1_month = 3
.lockdown_date_1_day = 21
.lockdown_date_2_year = 2020
.lockdown_date_2_month = 5
.lockdown_date_2_day = 13

# Database control
.deltas = True
```

### Extractor {#extractor}

We also have a custom `extractor` function, that saves the outputs as a compressed SQL database called `stages.db.bz2`. This is important since the outputs are very large (all classes across all days and all wards, for multiple replicates of each design point). The database contains four tables:

* `genpop_totals`
* `hospital_totals`
* `asymp_totals`
* `critical_totals`

You will notice these are named after the different **demographics**. Each table contains entries for:

* `ward`, `day`, `stage_0`, `stage_1`, `stage_2`, `stage_3`, `stage_4`, `stage_5`

For the `genpop` demographic, these correspond to:

* `stage_0`: **new** infections on each day (i.e. new moves into $E$)
* `stage_1`: current infections on each day (i.e. number of individuals in $E$)
* `stage_2`: **new** infectious individuals on each day (i.e. new moves into $I$)
* `stage_3`: current infectious individuals on each day (i.e. number of individuals in $I$)
* `stage_4`: current removals on each day (i.e. number of individuals in $R$)
* `stage_5`: current deaths on each day (i.e. number of individuals in $D$)

The other demographics (`asymp`, `hospital` and `critical`) have the same structure, but with `stage_0` and `stage_1` **always 0** (since new infections are always in `genpop`), and `stage_2` and `stage_3` correspond to the new and current numbers in either the $A$, $H$ or $C$ classes according to the demographic (refer to the model structure [here](#modelS)).

### Input and output code {#code}

To run designs, we need to generate a `disease.csv` file containing different parameters to use for different runs. For consistency, we will define three spaces:

* *input* space: this relates to the parameters ranges (defined below);
* *design* space: this will usually be in $(0, 1)$ or $(-1, 1)$ space;
* *disease* space: this relates to parameters that are fed into MetaWards.

The *input* and *design* spaces are fairly trivial to convert between, but some more work has to be done to convert between the *input* space and the *disease* space.

The current *input* parameter ranges are:
\begin{align}
    \mbox{$R_0$}&: (2.5, 4)\\
    \mbox{mean incubation period ($T_E$)}&: (4, 6)\\
    \mbox{mean infectious period ($T_I$)}&: (2, 4)\\
    \mbox{mean hospital stay ($T_H$)}&: (4, 12)\\
    \mbox{mean stay in critical care ($T_C$)}&: (4, 12)\\
    \mbox{lockdown 1 restrict}&: (0, 1)\\
    \mbox{lockdown 2 release}&: (0, 1)\\
    p_{EA}&: (0, 1)\\
    p_{IH}&: (0, 1)\\
    p_{IR}&: (0, 1) \quad \mbox{such that}~\sum_{i \in \{H, R\}} p_{Ii} < 1\\
    p_{HC}&: (0, 1)\\
    p_{HR}&: (0, 1) \quad \mbox{such that}~\sum_{i \in \{C, R\}} p_{Hi} < 1\\
    p_{CR}&: (0, 1)\\
    \beta^S_{A \to GP}&: (0, 1)\\
    \beta^S_{H \to GP}&: (0, 1)\\
    \beta^S_{C \to GP}&: (0, 1)
\end{align}
(The $\beta^S_{C \to GP}$ type parameters are the scaling rates used in the interaction matrix.)

We need: **ranges for the length of hospital stay** (perhaps chat to Rob Challen)? Current hospital rough guides taken from [https://www.medrxiv.org/content/10.1101/2020.04.23.20076042v1.full.pdf](https://www.medrxiv.org/content/10.1101/2020.04.23.20076042v1.full.pdf). (I've stuck in IQR for comparison, but clearly we need to think about this more.)

To ensure orthogonality, we could reparameterise such that:
\begin{align}
    p_{IR} &= \left(1 - p_{IH}\right) p^\prime_{IR}\\
    p_{HR} &= \left(1 - p_{HC}\right) p^\prime_{HR}
\end{align}
and thus we have parameter ranges:
\begin{align}
    \mbox{$R_0$}&: (2.5, 4)\\
    \mbox{mean incubation period ($T_E$)}&: (4, 6)\\
    \mbox{mean infectious period ($T_I$)}&: (2, 4)\\
    \mbox{mean hospital stay ($T_H$)}&: (4, 12)\\
    \mbox{mean time in critical care ($T_C$)}&: (4, 12)\\
    \mbox{lockdown 1 restrict}&: (0, 1)\\
    \mbox{lockdown 2 release}&: (0, 1)\\
    p_{EA}&: (0, 1)\\
    p_{IH}&: (0, 1)\\
    p^\prime_{IR}&: (0, 1)\\
    p_{HC}&: (0, 1)\\
    p^\prime_{HR}&: (0, 1)\\
    p_{CR}&: (0, 1)\\
    \beta^S_{A \to GP}&: (0, 1)\\
    \beta^S_{H \to GP}&: (0, 1)\\
    \beta^S_{C \to GP}&: (0, 1)
\end{align}
and this has removed the sum-to-one-constraints. 

In R we can set up the *input* parameter ranges as follows:


```r
## set up parameter ranges
parRanges <- data.frame(
    parameter = c("r_zero", "incubation_time", "infectious_time", "hospital_time",
                  "critical_time", "lock_1_restrict", "lock_2_release",
                  "pEA", "pIH", "pIRprime", "pHC", "pHRprime", "pCR", 
                  "GP_A", "GP_H", "GP_C"),
    lower = c(2.5, 4, 2, 4, 4, rep(0, 11)),
    upper = c(4, 6, 4, 12, 12, rep(1, 11)),
    stringsAsFactors = FALSE
)
```

Firstly we want a function to convert between the *design* and *input* spaces. A short R function called `convertDesignToInput()` which does this is given below. This requires a `design` data frame with columns denoting each *input* parameter in `parRanges` and rows corresponding to design points. There should be an additional column called `output` that defines a unique identifier for each design point, and a column called `repeats` that contains the number of repeats for each design point. The `convertDesignToInput()` function also requires the `parRanges` data frame (defined above). We use the `scale` argument to define whether the design is on the $(0, 1)$ (`scale = "zero_one"`) or $(-1, 1)$ (`scale = "negone_one"`) space.

> **Note**: this function converts the probabilities correctly for the `mover` defined [above](#mover).




```r
## function to convert from design to input space
convertDesignToInput <- function(design, parRanges, scale = c("zero_one", "negone_one")) {
  
    require(dplyr)
    require(tidyr)
  
    ## convert from design space to input space
    input <- mutate(design, ind = 1:n()) %>%
        gather(parameter, value, -output, -ind, -repeats) %>%
        left_join(parRanges, by = "parameter")
    if(scale[1] == "negone_one") {
        input <- mutate(input, value = value / 2 + 1)
    }
    input <- mutate(input, value = value * (upper - lower) + lower) %>%
        dplyr::select(ind, output, repeats, parameter, value) %>%
        spread(parameter, value) %>%
        arrange(ind) %>%
        dplyr::select(-ind)
    
    ## return inputs
    input
}
```

Once we have done this, we need to transform from the *input* space to the *disease* space for MetaWards. An R function is given below. This requires an `input` data frame, with columns denoting each *input* parameter and rows corresponding to each input points, a number of `repeats` and a column of unique identifiers (`output`).



```r
## function to convert from input to disease space
convertInputToDisease <- function(input) {
   
    require(dplyr)
    
    ## common parameters to all pathways
    disease <- tibble(`beta[2]` = input$r_zero / input$infectious_time)
    disease$`beta[3]` <- disease$`beta[2]`
    
    ## progressions out of the E class
    ## (adjusting in the way described in the vignette for
    ## order of movers)
    disease$`.pE` <- 1 - exp(-1 / input$incubation_time)
    disease$`.pEA` <- input$pEA
    
    ## progressions out of the A class
    disease$`.pA` <- 1 - exp(-1 / input$infectious_time)
    
    ## progressions out of the I class
    ## (adjusting in the way described in the vignette for
    ## order of movers)
    disease$`.pI` <- 1 - exp(-1 / input$infectious_time)
    disease$`.pIH` <- input$pIH
    disease$`.pIR` <- (1 - input$pIH) * input$pIRprime
    
    ## progressions out of the H class
    ## (adjusting in the way described in the vignette for
    ## order of movers)
    disease$`.pH` <- 1 - exp(-1 / input$hospital_time)
    disease$`.pHC` <- input$pHC
    disease$`.pHR` <- (1 - input$pHC) * input$pHRprime
    
    ## progressions out of the C class
    ## (adjusting in the way described in the vignette for
    ## order of movers)
    disease$`.pC` <- 1 - exp(-1 / input$critical_time)
    disease$`.pCR` <- input$pCR
    
    ## lockdown scalings
    disease$`.lock_1_restrict` <- input$lock_1_restrict
    disease$`.lock_2_release` <- input$lock_2_release
    
    ## set up scaling for mixing matrix
    disease$`.GP_A` <- input$GP_A
    disease$`.GP_H` <- input$GP_H
    disease$`.GP_C` <- input$GP_C
    
    ## finalise number of repeats
    disease$repeats <- input$repeats
    
    ## copy hash for each input
    disease$output <- input$output
    
    ## return disease file
    disease
}
```

Also in `dataTools.R` is a function `ensembleIDGen()` that creates unique IDs for each design point. So an example of a quick LHS design for five design points and five replicates is:


```r
## load libraries
library(lhs)
library(dplyr)
library(tidyr)

## source dataTools
source("R_tools/dataTools.R")

## set up parameter ranges
parRanges <- data.frame(
    parameter = c("r_zero", "incubation_time", "infectious_time", "hospital_time",
                  "critical_time", "lock_1_restrict", "lock_2_release",
                  "pEA", "pIH", "pIRprime", "pHC", "pHRprime", "pCR", 
                  "GP_A", "GP_H", "GP_C"),
    lower = c(2.5, 4, 2, 4, 4, rep(0, 11)),
    upper = c(4, 6, 4, 12, 12, rep(1, 11)),
    stringsAsFactors = FALSE
)
print("NEED TO GET RANGES FIGURED OUT, THIS IS A TEST")

## generate LHS design
design <- randomLHS(5, nrow(parRanges))
colnames(design) <- parRanges$parameter
design <- as_tibble(design)

## add unique hash identifier
## (at the moment don't use "a0" type ensembleID, because MetaWards
## parses to dates)
design$output <- ensembleIDGen(ensembleID = "Ens0", nrow(design))
design$repeats <- 2

## convert to input space
input <- convertDesignToInput(design, parRanges, "zero_one")

## convert input to disease
disease <- convertInputToDisease(input)

## write to external files
dir.create("inputs", showWarnings = FALSE)

## write text file for MetaWards
write.table(disease, "inputs/disease.dat", row.names = FALSE, sep = " ", quote = FALSE)

## save inputs for data for post-simulation runs
saveRDS(design, "inputs/design.rds")
saveRDS(parRanges, "inputs/parRanges.rds")
```

This produces a file `inputs/disease.dat` that can be passed to MetaWards to run the model. The `runscript.sh` batch file provides the command line instructions needed to the model using these inputs. This is written for Linux, and should be able to be run directly from the downloaded folder. If you don't run Linux, then the file should give you an idea of how to run the model on your own system.

The outputs from MetaWards are stored in an SQL database, which can be queried through any SQLite client. Each model run produces a file called `stages.db.bz2`, which is a compressed database containing the outputs. As an example, migrate to an output folder containing `stages.db.bz2`. To access the outputs you will first have to unzip this file. I do this on the command line e.g.

```
bzip2 -dk stages.db.bz2
```

If you're happy with SQL, you can query these directly with e.g. SQLite. If you are an R user, then the `dplyr` package (or more specifically the `dbplyr` package) provides some useful R tools for querying SQL databases using `tidyverse`-type notation. More details can be found [here](https://cran.r-project.org/web/packages/dbplyr/vignettes/dbplyr.html).

As a quick example, imagine that we want to extract the **cumulative hospital cases** on say day 100. Here we will need to extract the **new hospital cases** from day 1--100, and then sum them up for each ward. Therefore we need to extract `day`, `ward` and `stage_2` from the `hospital_totals` table, and then sum them up (see [here](#extractor) for more details on how the outputs are stored). For speed, `dplyr` converts the R code to SQL, and only pulls the resulting table to R if you run the function `collect()` (see below).


```r
## load library
## (you might also need to install the 'RSQLite' 
## and `dbplyr` packages which 'dplyr' calls)
library(dplyr)

## establish connection to database
con <- DBI::dbConnect(RSQLite::SQLite(), "stages.db")

## connect to the 'hospital_totals' table
hospital <- tbl(con, "hospital_totals")

## stage_2 contains the new cases, so sum these
## over each ward for days 1--100 
## (NOTE: `hosp_db` contains the query not the outcome,
## so 'show_query(hosp_db)' can view this if you like)
hosp_db <- filter(hospital, day <= 100) %>%
    select(ward, stage_2) %>%
    group_by(ward) %>%
    summarise(cH = sum(stage_2))

## run query and pull to R
hosp <- collect(hosp_db)

## disconnect from database
DBI::dbDisconnect(con)
```

Now you can play with `hosp` as much as you like. Note that after you've pulled the correct outputs down, you might want to delete the `stage.db` (**NOT** the `stages.db.bz2`) file. I did this on the Unix command line using:

```
rm stage.db
```

> **Be careful**: remember that `rm` removes completely, so not to the recycle bin. However, as long as you don't remove `stages.db.bz2` then you can always recover.

You can very easily wrap these ideas into an R function that can scroll through the design IDs, extract relevant outputs and bind to the inputs. An example that you are free to edit at will can be found in the `extractOutputs.R` file in the repo. **At the current time this relies on some OS-specific code, in order to unzip the compressed SQL database files.**


```
## [1] "NEED TO GET RANGES FIGURED OUT, THIS IS A TEST"
```

